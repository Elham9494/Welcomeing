export default function Home() {
  return (
    <div style={{ textAlign: 'center', padding: '50px', fontFamily: 'sans-serif' }}>
      <h1>🦷 دندانپزشکی برای همه</h1>
      <p>به وبلاگ ساده و مفید دندانپزشکی خوش آمدید!</p>
      <p>اگه دندون‌درد داری و دسترسی به دندانپزشک نداری، من اینجام که کمکت کنم 💬</p>
    </div>
  );
}
